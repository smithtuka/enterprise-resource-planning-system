package com.galbern.requisitionservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RequisitionServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
