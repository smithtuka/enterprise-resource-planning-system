package com.galbern.requisitionservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RequisitionServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RequisitionServiceApplication.class, args);
	}

}
